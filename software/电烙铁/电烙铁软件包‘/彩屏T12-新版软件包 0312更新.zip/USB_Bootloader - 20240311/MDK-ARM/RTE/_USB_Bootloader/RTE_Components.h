
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'USB_Bootloader_20240310' 
 * Target:  'USB_Bootloader' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "air32f10x.h"



#endif /* RTE_COMPONENTS_H */
